export class SellerModel {
    name: string;
    password:string;
    companyName:string;
    companyDescription:string;
    gstin:string;
    postalAddress:string;
    website:string;
    emailId:string;
    mobileNo:number;
}